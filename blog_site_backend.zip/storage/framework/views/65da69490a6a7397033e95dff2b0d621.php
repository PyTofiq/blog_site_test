<?php $__env->startSection('content'); ?>
<div class="container">

    <h2>Category table</h2>
    <a class="btn btn-success mb-5">Create new category</a>
    <table class="table table-hover">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Count</th>
                <th scope="col">Actions</th>
            </tr>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($category->name); ?></td>
                        <td></td>
                        <td>
                            <a class="btn btn-outline-success">Edit</a>
                            <a class="btn btn-outline-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </thead>
    </table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/admin/categories.blade.php ENDPATH**/ ?>