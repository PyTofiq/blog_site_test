<?php $__env->startSection('content'); ?>



<div class="container">
    <h1 class="mt-5 mb-5">Category: <?php echo e($category->name); ?></h1>

    <div class="blogs row mt-5">
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blog col-md-3">
            <div class="card">
              <img src="<?php if($blog->image): ?> <?php echo e(asset('uploads/blogs/'.$blog->image)); ?> <?php else: ?> <?php echo e(asset('uploads/default.png')); ?> <?php endif; ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title"><a href="<?php echo e(route('blog-details', $blog->id)); ?>"><?php echo e($blog->title); ?></a></h5>
                <p class="card-text">
                    <?php if($blog->categories): ?>
                    <?php $__currentLoopData = $blog->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span><?php echo e($cat->name); ?>,</span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </p>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/web/blogs/blog-category.blade.php ENDPATH**/ ?>