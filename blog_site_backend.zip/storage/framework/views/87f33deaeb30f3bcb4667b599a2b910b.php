<?php $__env->startSection('content'); ?>


<div class="container">
    <form action="<?php echo e(route('admin-blog-edit', $old->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-floating mt-5 mb-5">
            <input type="text" class="form-control" id="input" name="name" value="<?php echo e($old->title); ?>">
            <label for="input">Title</label>
          </div>
          <div class="form-floating mt-5 mb-5">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" name="description"><?php echo e($old->description); ?></textarea>
            <label for="floatingTextarea">Description</label>
          </div>
          <div class="btn-group mt-5 mb-5" role="group" aria-label="Basic checkbox toggle button group">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $isChecked = in_array($category->id, $old->categories->pluck('id')->toArray()); ?>
            <input type="checkbox" class="btn-check" id="btncheck-category-<?php echo e($category->id); ?>" name="category[]" <?php echo e($isChecked ? 'checked' : ''); ?> value="<?php echo e($category->id); ?>">
            <label class="btn btn-outline-primary" for="btncheck-category-<?php echo e($category->id); ?>"><?php echo e($category->name); ?></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          <select class="form-select" aria-label="Default select example" name="author">
            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($author->id); ?>" <?php if($old->author_id == $author->id): ?> selected <?php endif; ?>><?php echo e($author->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <img src="<?php if($old->image): ?> <?php echo e(asset('uploads/blogs/'.$old->image)); ?> <?php else: ?> <?php echo e(asset('uploads/default.png')); ?> <?php endif; ?>" alt="" width="100px" height="100px" class="mt-5 mb-5">
          <div class="mb-3">
            <label for="formFile" class="form-label">Default file input example</label>
            <input class="form-control" type="file" id="formFile" name="image">
          </div>

          <button class="btn btn-success mt-5" type="submit">Edit Blog</button>

    </form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/admin/blogs/edit.blade.php ENDPATH**/ ?>