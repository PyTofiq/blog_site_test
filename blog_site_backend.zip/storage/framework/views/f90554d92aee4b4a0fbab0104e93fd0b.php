<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body>


    <div class="container mb-5 mt-5">
        <div class="navbar d-flex justify-content-between">
            <div class="nav-list d-flex">
                <h3>Blog website</h3>
                <ul>
                    <li><a href="<?php echo e(route('blogs')); ?>">Home</a></li>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('blog-category', $category->id)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php if(auth()->guard()->check()): ?>
            <div>
                <a href="<?php echo e(route('profile')); ?>">Profile</a>
                <a href="<?php echo e(route('logout')); ?>">Logout</a>
            </div>
            <?php else: ?>
            <div>
                <a href="<?php echo e(route('login-page')); ?>">Log in</a>
                <a href="<?php echo e(route('register-page')); ?>">Register</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/web/layout/header.blade.php ENDPATH**/ ?>