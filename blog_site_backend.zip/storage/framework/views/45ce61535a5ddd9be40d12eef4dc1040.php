<?php $__env->startSection('content'); ?>

    <div class="container">

        <div class="blog-details">
            <?php if($isUser): ?>
            <div class="mb-5">
                <a href="<?php echo e(route('blog-edit-page', $blog->id)); ?>" class="btn btn-success">Edit</a>
                <a href="<?php echo e(route('blog-delete', $blog->id)); ?>" class="btn btn-danger">Delete</a>
            </div>
            <?php endif; ?>

            
            <?php if($blog->image): ?>
            <div class="blog-image mb-5">
                <img src="<?php echo e(asset('uploads/blogs/'.$blog->image)); ?>" alt="" width="100px" height="100px">
            </div>
            <?php endif; ?>

            <div class="blog-title">
                <h1>Title</h1>
                <p><?php echo e($blog->title); ?></p>
            </div>
            <div class="blog-date mt-5 mb-5">
                <h5>Date</h5>
                <p><?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d-m-Y')); ?></p>
            </div>
            <div class="blog-author mt-5 mb-5">
                <h5>Author</h5>
                <p><?php echo e($blog->authors->name); ?></p>
            </div>

            <?php if($blog->categories): ?>
            <div class="blog-categories mt-5 mb-5">
                <h4>Categories</h4>
                <?php $__currentLoopData = $blog->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($category->name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <div class="blog-text mt-5 mb-5">
                <h4>Description</h4>
                <p><?php echo e($blog->description); ?></p>
            </div>
        </div>


        <?php if($blogs->count()): ?>

        <div class="related-blogs mb-5 mt-5">
            <h3>Related Blogs:</h3>
            <div class="blogs row mt-5">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="blog col-md-3">
                    <div class="card">
                      <img src="<?php if($blog->image): ?> <?php echo e(asset('uploads/blogs/'.$blog->image)); ?> <?php else: ?> <?php echo e(asset('uploads/default.png')); ?> <?php endif; ?>" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title"><a href="<?php echo e(route('blog-details', $blog->id)); ?>"><?php echo e($blog->title); ?></a></h5>
                        <p class="card-text">
                            <?php if($blog->categories): ?>
                            <?php $__currentLoopData = $blog->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span><?php echo e($cat->name); ?>,</span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </p>
                      </div>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>


        <?php endif; ?>



    </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/web/blogs/blog-details.blade.php ENDPATH**/ ?>