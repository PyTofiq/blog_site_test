<?php $__env->startSection('content'); ?>

<div class="container">
    <form action="<?php echo e(route('blog-add-post')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-floating mt-5 mb-5">
            <input type="text" class="form-control" id="input" name="name">
            <label for="input">Title</label>
          </div>
          <div class="form-floating mt-5 mb-5">
            <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" name="description"></textarea>
            <label for="floatingTextarea">Description</label>
          </div>
          <div class="btn-group mt-5 mb-5" role="group" aria-label="Basic checkbox toggle button group">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <input type="checkbox" class="btn-check" id="btncheck-category-<?php echo e($category->id); ?>" name="category[]" value="<?php echo e($category->id); ?>">
            <label class="btn btn-outline-primary" for="btncheck-category-<?php echo e($category->id); ?>"><?php echo e($category->name); ?></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <div>
          </div>
          <div class="mb-3">
            <label for="formFile" class="form-label">Default file input example</label>
            <input class="form-control" type="file" id="formFile" name="image">
          </div>

          <button class="btn btn-success mt-5" type="submit">Add Blog</button>

    </form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/web/blogs/blog-add.blade.php ENDPATH**/ ?>