<?php $__env->startSection('content'); ?>

<div class="container mt-5">

    <h4>Register</h4>

    <form action="<?php echo e(route('register-post')); ?>" method="POST" enctype="muiltipart-data">
    <?php echo csrf_field(); ?>

    <div class="form-floating mt-5">
        <input type="text" class="form-control" id="admin-login-name" name="name" placeholder="name">
        <label for="admin-login-name">Name</label>
      </div>
          <div class="form-floating mt-5">
            <input type="email" class="form-control" id="admin-login-email" name="email" placeholder="name@example.com">
            <label for="admin-login-email">Email</label>
          </div>
          <div class="form-floating mt-5 mb-5">
            <input type="password" class="form-control" id="admin-login-password" name="password" >
            <label for="admin-login-password">Password</label>
          </div>
          <?php $__errorArgs = ['errors'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert alert-danger"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <button class="btn btn-primary mt-5 mb-5" type="submit">Submit</button>

    </form>

</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/web/register.blade.php ENDPATH**/ ?>