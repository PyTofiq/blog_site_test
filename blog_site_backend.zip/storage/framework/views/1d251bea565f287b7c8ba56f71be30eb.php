<?php $__env->startSection('content'); ?>

<div class="container">
    <form action="<?php echo e(route('admin-category-edit', $old->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-floating mt-5">
            <input type="text" class="form-control" id="input" name="name" value="<?php echo e($old->name); ?>">
            <label for="input">Name</label>
          </div>

          <button class="btn btn-success mt-5" type="submit">Edit category</button>

    </form>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>