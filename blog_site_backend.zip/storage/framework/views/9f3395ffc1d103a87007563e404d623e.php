<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>
<body>

    <div class="container mt-5">

        <h4>Login</h4>

        <form action="<?php echo e(route('admin-login-post')); ?>" method="POST">
        <?php echo csrf_field(); ?>
              <div class="form-floating mt-5">
                <input type="email" class="form-control" id="admin-login-email" name="email" placeholder="name@example.com">
                <label for="admin-login-email">Email</label>
              </div>
              <div class="form-floating mt-5 mb-5">
                <input type="password" class="form-control" id="admin-login-password" name="password" >
                <label for="admin-login-password">Password</label>
              </div>
              <?php $__errorArgs = ['admin-login-email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="alert alert-danger"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

              <button class="btn btn-primary mt-5 mb-5" type="submit">Submit</button>

        </form>

    </div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>


</body>
</html>
<?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/admin/login.blade.php ENDPATH**/ ?>