@include('web.layout.header')
@yield('content')
@include('web.layout.footer')
